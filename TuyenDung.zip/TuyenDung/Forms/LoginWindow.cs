﻿using System;
using System.Linq;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.Forms
{
    public partial class LoginWindow : Form
    {

        private QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public LoginWindow()
        {
            InitializeComponent();
            QL_TuyenDungEntities = new QL_TuyenDungEntities();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var user = QL_TuyenDungEntities.account_user
                .SingleOrDefault(x => x.user_name.Equals(txtUserName.Text) && x.password.Equals(txtPassword.Text));
            if (user == null)
            {
                MessageBox.Show("Tài khoản hoặc mật khẩu không chính xác.", "Đăng nhập không thành công", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            this.Hide();
            MainWindow main = new MainWindow(QL_TuyenDungEntities, user);
            var result = main.ShowDialog();
            if (result == DialogResult.Yes)
            {
                this.Show();
            }
            else if (result == DialogResult.No)
            {
                this.Close();
            }
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            var user = QL_TuyenDungEntities.account_user.SingleOrDefault(x => x.user_name.Equals(txtSignUpUsername.Text));
            if (user != null)
            {
                MessageBox.Show("Tài khoản đã tồn tại, vui lòng chọn tài khoản khác", "Đăng ký không thành công", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            user = new account_user()
            {
                id = Guid.NewGuid().ToString(),
                user_name = txtSignUpUsername.Text,
                password = txtSignUpPassword.Text,
                role_user = cboRole.SelectedValue.ToString()
            };
            QL_TuyenDungEntities.account_user.Add(user);
            QL_TuyenDungEntities.SaveChanges();

            var userInfo = new info_user()
            {
                id = Guid.NewGuid().ToString(),
                account_user = user.id
            };
            QL_TuyenDungEntities.info_user.Add(userInfo);
            QL_TuyenDungEntities.SaveChanges();
            MessageBox.Show("Đăng ký tài khoản thành công, vui lòng đăng nhập để sử dụng dịch vụ.", "Đăng ký thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = true;
        }

        private void LoginWindow_Load(object sender, EventArgs e)
        {
            cboRole.DataSource = QL_TuyenDungEntities
                .role_user
                .Where(x => !x.id.Equals("1") && !x.id.Equals("3"))
                .ToList();
            cboRole.ValueMember = "id";
            cboRole.DisplayMember = "name_role";
        }
    }
}
