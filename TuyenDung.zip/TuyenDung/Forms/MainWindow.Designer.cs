﻿namespace TuyenDung
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.mainPanel = new System.Windows.Forms.Panel();
            this.headerPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnTaiKhoan = new TuyenDung.UserControls.HeaderButton();
            this.btnCongTy = new TuyenDung.UserControls.HeaderButton();
            this.btnTTCaNhan = new TuyenDung.UserControls.HeaderButton();
            this.btnVTTuyenDung = new TuyenDung.UserControls.HeaderButton();
            this.btnTrangChu = new TuyenDung.UserControls.HeaderButton();
            this.headerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Location = new System.Drawing.Point(0, 60);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(968, 450);
            this.mainPanel.TabIndex = 0;
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.Color.Black;
            this.headerPanel.Controls.Add(this.btnTaiKhoan);
            this.headerPanel.Controls.Add(this.btnCongTy);
            this.headerPanel.Controls.Add(this.btnTTCaNhan);
            this.headerPanel.Controls.Add(this.btnVTTuyenDung);
            this.headerPanel.Controls.Add(this.btnTrangChu);
            this.headerPanel.Controls.Add(this.pictureBox1);
            this.headerPanel.Location = new System.Drawing.Point(0, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(990, 60);
            this.headerPanel.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnTaiKhoan
            // 
            this.btnTaiKhoan.IsChecked = false;
            this.btnTaiKhoan.LabelText = null;
            this.btnTaiKhoan.Location = new System.Drawing.Point(914, 0);
            this.btnTaiKhoan.Name = "btnTaiKhoan";
            this.btnTaiKhoan.Size = new System.Drawing.Size(155, 60);
            this.btnTaiKhoan.TabIndex = 8;
            this.btnTaiKhoan.Click += new System.EventHandler(this.btnTaiKhoan_Click);
            // 
            // btnCongTy
            // 
            this.btnCongTy.IsChecked = false;
            this.btnCongTy.LabelText = null;
            this.btnCongTy.Location = new System.Drawing.Point(745, 0);
            this.btnCongTy.Name = "btnCongTy";
            this.btnCongTy.Size = new System.Drawing.Size(115, 60);
            this.btnCongTy.TabIndex = 7;
            this.btnCongTy.Click += new System.EventHandler(this.btnCongTy_Click);
            // 
            // btnTTCaNhan
            // 
            this.btnTTCaNhan.IsChecked = false;
            this.btnTTCaNhan.LabelText = null;
            this.btnTTCaNhan.Location = new System.Drawing.Point(480, 0);
            this.btnTTCaNhan.Name = "btnTTCaNhan";
            this.btnTTCaNhan.Size = new System.Drawing.Size(235, 60);
            this.btnTTCaNhan.TabIndex = 6;
            this.btnTTCaNhan.Click += new System.EventHandler(this.userControl13_Click);
            // 
            // btnVTTuyenDung
            // 
            this.btnVTTuyenDung.IsChecked = false;
            this.btnVTTuyenDung.LabelText = null;
            this.btnVTTuyenDung.Location = new System.Drawing.Point(280, 0);
            this.btnVTTuyenDung.Name = "btnVTTuyenDung";
            this.btnVTTuyenDung.Size = new System.Drawing.Size(170, 60);
            this.btnVTTuyenDung.TabIndex = 5;
            this.btnVTTuyenDung.Click += new System.EventHandler(this.userControl12_Click);
            // 
            // btnTrangChu
            // 
            this.btnTrangChu.IsChecked = false;
            this.btnTrangChu.LabelText = null;
            this.btnTrangChu.Location = new System.Drawing.Point(100, 0);
            this.btnTrangChu.Name = "btnTrangChu";
            this.btnTrangChu.Size = new System.Drawing.Size(150, 60);
            this.btnTrangChu.TabIndex = 4;
            this.btnTrangChu.Click += new System.EventHandler(this.userControl11_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1111, 528);
            this.Controls.Add(this.headerPanel);
            this.Controls.Add(this.mainPanel);
            this.Name = "MainWindow";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.MainWindow_SizeChanged);
            this.headerPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        public UserControls.HeaderButton btnTrangChu;
        public UserControls.HeaderButton btnTTCaNhan;
        public UserControls.HeaderButton btnVTTuyenDung;
        public UserControls.HeaderButton btnCongTy;
        public UserControls.HeaderButton btnTaiKhoan;
    }
}

