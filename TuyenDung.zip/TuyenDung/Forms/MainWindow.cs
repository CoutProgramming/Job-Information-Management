﻿using System;
using System.Windows.Forms;
using TuyenDung.Models;
using TuyenDung.UserControls;

namespace TuyenDung
{
    public partial class MainWindow : Form
    {
        private QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        private account_user User { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            QL_TuyenDungEntities = new QL_TuyenDungEntities();
        }

        public MainWindow(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnTrangChu.LabelText = "Trang chủ";
            btnTrangChu.IsChecked = true;
            ShowContent(new Home(QL_TuyenDungEntities, User));
            btnVTTuyenDung.LabelText = "Tuyển dụng";
            btnTTCaNhan.LabelText = "Thông tin cá nhân";
            btnCongTy.LabelText = "Công ty";
            btnTaiKhoan.LabelText = "Tài khoản";
            CheckRole();
            MainWindow_SizeChanged(sender, e);
        }

        private void CheckRole()
        {
            btnTaiKhoan.Visible = false;
            switch(User.role_user)
            {
                case "1":
                    btnTaiKhoan.Visible = true;
                    break;
                case "2":
                    btnCongTy.Visible = false;
                    break;
                case "3":
                    break;
                case "4":
                    break;
            }
        }

        public void ChangeView(int viewNumber)
        {
            btnTrangChu.IsChecked = false;
            btnVTTuyenDung.IsChecked = false;
            btnTTCaNhan.IsChecked = false;
            btnCongTy.IsChecked = false;
            btnTaiKhoan.IsChecked = false;
            switch (viewNumber)
            {
                case 1:
                    btnTrangChu.IsChecked = true;
                    ShowContent(new Home(QL_TuyenDungEntities, User));
                    break;
                case 2:
                    btnVTTuyenDung.IsChecked = true;
                    ShowContent(new Job(QL_TuyenDungEntities, User));
                    break;
                case 3:
                    btnTTCaNhan.IsChecked = true;
                    ShowContent(new EditUserInformation(QL_TuyenDungEntities, User));
                    break;
                case 4:
                    btnCongTy.IsChecked = true;
                    ShowContent(new Company(QL_TuyenDungEntities, User));
                    break;
                case 5:
                    btnTaiKhoan.IsChecked = true;
                    ShowContent(new Account(QL_TuyenDungEntities, User));
                    break;
            }
        }

        private void userControl11_Click(object sender, EventArgs e)
        {
            ChangeView(1);
        }

        private void userControl12_Click(object sender, EventArgs e)
        {
            ChangeView(2);
        }

        private void userControl13_Click(object sender, EventArgs e)
        {
            ChangeView(3);
        }

        private void ShowContent(UserControl content)
        {
            mainPanel.Controls.Clear();
            mainPanel.Controls.Add(content);
            content.Dock = DockStyle.Fill;
        }

        private void btnCongTy_Click(object sender, EventArgs e)
        {
            ChangeView(4);
        }

        private void MainWindow_SizeChanged(object sender, EventArgs e)
        {
            headerPanel.Width = this.Width;
            mainPanel.Height = this.Height - 60;
            mainPanel.Width = this.Width;
        }

        private void btnTaiKhoan_Click(object sender, EventArgs e)
        {
            ChangeView(5);
        }
    }
}
