﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class Home : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();
        public Home()
        {
            InitializeComponent();
        }

        public Home(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void Home_Load(object sender, EventArgs e)
        {
            dtgData.AutoGenerateColumns = false;

            DataGridViewTextBoxColumn column0 = new DataGridViewTextBoxColumn();
            column0.DataPropertyName = "id";
            column0.Visible = false;

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "accountID";
            column1.HeaderText = "Ứng viên";
            column1.Name = "nameUser";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "status_apply";
            column2.HeaderText = "Trạng thái tuyển dụng";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "candidate_status";
            column3.HeaderText = "Trạng thái ứng viên";

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "jobID";
            column4.HeaderText = "Vị trí đơn ứng tuyển";
            column4.Name = "jobTitle";

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "jobID";
            column5.HeaderText = "Mức độ ưu tiên";
            column5.Name = "priority";

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "jobID";
            column6.HeaderText = "Mức lương";
            column6.Name = "salary";

            DataGridViewButtonColumn column7 = new DataGridViewButtonColumn();
            column7.Name = "Edit";
            column7.Text = "Sửa";
            column7.UseColumnTextForButtonValue = true;

            DataGridViewButtonColumn column8 = new DataGridViewButtonColumn();
            column8.Name = "Delete";
            column8.Text = "Xóa";
            column8.UseColumnTextForButtonValue = true;

            dtgData.Columns.Add(column0);
            dtgData.Columns.Add(column1);
            dtgData.Columns.Add(column2);
            dtgData.Columns.Add(column3);
            dtgData.Columns.Add(column4);
            dtgData.Columns.Add(column5);
            dtgData.Columns.Add(column6);
            if (!User.role_user.Equals("2"))
            {
                dtgData.Columns.Add(column7);
                dtgData.Columns.Add(column8);
            }
            LoadData();
        }

        private void LoadData(IQueryable<apply> data = null)
        {
            data = data ?? QL_TuyenDungEntities.applies
                .Include("account_user")
                .Include("info_Job");
            if (User.role_user.Equals("2"))
            {
                data = data.Where(x => x.accountID.Equals(User.id));
            }
            dtgData.DataSource = data.ToList();
            dtgData.Refresh();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var data = QL_TuyenDungEntities.applies
                .Include("account_user")
                .Include("account_user.info_user")
                .Include("info_Job")
                .Where(x => x.account_user.info_user
                    .FirstOrDefault().name_user.ToLower()
                    .Contains(txtSearch.Text.ToLower())
                    || x.info_Job.title.ToLower()
                    .Contains(txtSearch.Text.ToLower()));
            LoadData(data);
        }

        private void dtgData_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (sender is DataGridView dtgData)
            {
                if (dtgData.Columns[e.ColumnIndex].Name.Equals("nameUser"))
                {
                    string header = QL_TuyenDungEntities.info_user
                        .Where(info => info.account_user.Equals(e.Value.ToString()))
                        .FirstOrDefault()
                        .name_user;

                    e.Value = header;
                    e.FormattingApplied = true;
                }

                if (dtgData.Columns[e.ColumnIndex].Name.Equals("jobTitle"))
                {
                    string header = QL_TuyenDungEntities.info_Job
                        .Where(job => job.id.Equals(e.Value.ToString()))
                        .FirstOrDefault()
                        .title;

                    e.Value = header;
                    e.FormattingApplied = true;
                }

                if (dtgData.Columns[e.ColumnIndex].Name.Equals("priority"))
                {
                    string header = QL_TuyenDungEntities.info_Job
                        .Include("priority_level")
                        .Where(job => job.id.Equals(e.Value.ToString()))
                        .FirstOrDefault()
                        .priority_level
                        .name_priority;

                    e.Value = header;
                    e.FormattingApplied = true;
                }

                if (dtgData.Columns[e.ColumnIndex].Name.Equals("salary"))
                {
                    string header = QL_TuyenDungEntities.info_Job
                        .Where(job => job.id.Equals(e.Value.ToString()))
                        .FirstOrDefault()
                        .salary;

                    e.Value = header;
                    e.FormattingApplied = true;
                }
            }
        }

        private void Home_SizeChanged(object sender, EventArgs e)
        {
            resizeTimer.Interval = 200;
            resizeTimer.Tick += ResizeTimer_Tick;
            resizeTimer.Stop();
            resizeTimer.Start();
        }

        private void ResizeTimer_Tick(object sender, EventArgs e)
        {
            dtgData.Size = new System.Drawing.Size(this.Width - 65, this.Height - 190);
            headerPanel.Width = this.Width;
            btnAddApplication.Location = new System.Drawing.Point(this.Width - 185, btnAddApplication.Location.Y);
            resizeTimer.Stop();
        }

        private void btnAddApplication_Click(object sender, EventArgs e)
        {
            if (this.Parent != null)
            {
                AddApplication addApplication = new AddApplication(QL_TuyenDungEntities, User);

                this.Parent.Controls.Add(addApplication);

                ClearCurrentPanel();
            }
        }

        private void ClearCurrentPanel()
        {
            if (this.Parent.Controls.Count > 1)
            {
                Control existingControl = this.Parent.Controls[0];

                if (existingControl != null)
                {
                    existingControl.Dispose();
                }
            }
        }

        private void dtgData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 7)
                {
                    if (this.Parent != null)
                    {
                        EditApplication editApplication = new EditApplication(QL_TuyenDungEntities,
                            User,
                            dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());

                        this.Parent.Controls.Add(editApplication);

                        ClearCurrentPanel();
                    }
                }
                else if (e.ColumnIndex == 8)
                {
                    ClearRow(dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());
                    LoadData();
                }
                else if (this.Parent != null)
                {
                    DetailApplication detailApplication = new DetailApplication(QL_TuyenDungEntities,
                        User,
                        dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());

                    this.Parent.Controls.Add(detailApplication);

                    ClearCurrentPanel();
                }
            }
        }

        private void ClearRow(string applyId)
        {
            var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa đơn ứng tuyển này không?", "Xóa đơn ứng tuyển", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                var apply = QL_TuyenDungEntities.applies.SingleOrDefault(x => x.id.Equals(applyId));
                QL_TuyenDungEntities.applies.Attach(apply);
                QL_TuyenDungEntities.applies.Remove(apply);
                QL_TuyenDungEntities.SaveChanges();
                MessageBox.Show("Xóa đơn ứng tuyển thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
            }
        }
    }
}
