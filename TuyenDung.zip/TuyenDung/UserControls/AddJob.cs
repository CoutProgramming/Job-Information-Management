﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class AddJob : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();
        public AddJob()
        {
            InitializeComponent();
        }

        public AddJob(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void btnAddJob_Click(object sender, EventArgs e)
        {
            int.TryParse(txtHeadCount.Text, out var count);
            var job = new info_Job()
            {
                id = Guid.NewGuid().ToString(),
                title = txtTitle.Text,
                description_Job = txtDescription.Text,
                salary = txtSalary.Text,
                note = string.Empty,
                status_Job = "Đang mở",
                count = count,
                time_Create = DateTime.Now,
                priorityID = cboPriority.SelectedValue.ToString(),
                majorID = cboMajor.SelectedValue.ToString(),
                accountID = User.id,
                companyID = cboCompany.SelectedValue.ToString(),
                educationID = cboEducation.SelectedValue.ToString()
            };
            QL_TuyenDungEntities.info_Job.Add(job);
            QL_TuyenDungEntities.SaveChanges();
            MessageBox.Show("Thêm đơn ứng tuyển thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RedirectToJobPage();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RedirectToJobPage();
        }

        private void RedirectToJobPage()
        {
            if (this.Parent.Parent is MainWindow main)
            {
                main.ChangeView(2);
            }
        }

        private void AddJob_Load(object sender, EventArgs e)
        {
            cboPriority.DataSource = QL_TuyenDungEntities.priority_level.ToList();
            cboPriority.ValueMember = "id";
            cboPriority.DisplayMember = "name_priority";

            cboMajor.DataSource = QL_TuyenDungEntities.majors.ToList();
            cboMajor.ValueMember = "id";
            cboMajor.DisplayMember = "name_major";

            cboCompany.DataSource = QL_TuyenDungEntities.companies.ToList();
            cboCompany.ValueMember = "id";
            cboCompany.DisplayMember = "company_name";

            cboEducation.DataSource = QL_TuyenDungEntities.education_level.ToList();
            cboEducation.ValueMember = "id";
            cboEducation.DisplayMember = "name_level";
        }
    }
}
