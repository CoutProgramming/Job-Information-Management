﻿using System.Linq;
using System.Net;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class EditCompany : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        public string companyId { get; set; }
        private Timer resizeTimer = new Timer();
        public EditCompany()
        {
            InitializeComponent();
        }

        public EditCompany(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user, string companyId)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
            this.companyId = companyId;
        }

        private void EditCompany_Load(object sender, System.EventArgs e)
        {
            var company = QL_TuyenDungEntities.companies.SingleOrDefault(x => x.id.Equals(companyId));
            txtName.Text = company.company_name;
            txtAddress.Text = company.address;
            txtEmail.Text = company.email;
            txtPhoneNumber.Text = company.phone;
            txtDescription.Text = company.description_company;
        }

        private void btnAddJob_Click(object sender, System.EventArgs e)
        {
            var company = QL_TuyenDungEntities.companies.SingleOrDefault(x => x.id.Equals(companyId));
            company.company_name = txtName.Text;
            company.address = txtAddress.Text;
            company.email = txtEmail.Text;
            company.phone = txtPhoneNumber.Text;
            company.description_company = txtDescription.Text;
            QL_TuyenDungEntities.SaveChanges();
            MessageBox.Show("Sửa công ty thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RedirectToCompanyPage();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            RedirectToCompanyPage();
        }

        private void RedirectToCompanyPage()
        {
            if (this.Parent.Parent is MainWindow main)
            {
                main.ChangeView(4);
            }
        }
    }
}
