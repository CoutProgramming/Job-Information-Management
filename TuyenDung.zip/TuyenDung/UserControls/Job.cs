﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Markup;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class Job : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();
        public Job()
        {
            InitializeComponent();
        }

        public Job(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void Job_Load(object sender, EventArgs e)
        {
            dtgData.AutoGenerateColumns = false;

            DataGridViewTextBoxColumn column0 = new DataGridViewTextBoxColumn();
            column0.DataPropertyName = "id";
            column0.Visible = false;

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "title";
            column1.HeaderText = "Vị trí tuyển dụng";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "count";
            column2.HeaderText = "Số lượng yêu cầu";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "time_Create";
            column3.HeaderText = "Ngày yêu cầu";

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "end_time";
            column4.HeaderText = "Ngày hết hạn";

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "educationID";
            column5.HeaderText = "Trình độ học vấn";
            column5.Name = "educationLevel";

            DataGridViewTextBoxColumn column6 = new DataGridViewTextBoxColumn();
            column6.DataPropertyName = "priorityID";
            column6.HeaderText = "Mức độ ưu tiên";
            column6.Name = "priorityLevel";

            DataGridViewTextBoxColumn column7 = new DataGridViewTextBoxColumn();
            column7.DataPropertyName = "salary";
            column7.HeaderText = "Mức lương";

            DataGridViewButtonColumn column8 = new DataGridViewButtonColumn();
            column8.Name = "Edit";
            column8.Text = "Sửa";
            column8.UseColumnTextForButtonValue = true;

            DataGridViewButtonColumn column9 = new DataGridViewButtonColumn();
            column9.Name = "Delete";
            column9.Text = "Xóa";
            column9.UseColumnTextForButtonValue = true;

            dtgData.Columns.Add(column0);
            dtgData.Columns.Add(column1);
            dtgData.Columns.Add(column2);
            dtgData.Columns.Add(column3);
            dtgData.Columns.Add(column4);
            dtgData.Columns.Add(column5);
            dtgData.Columns.Add(column6);
            dtgData.Columns.Add(column7);
            if (!User.role_user.Equals("2"))
            {
                dtgData.Columns.Add(column8);
                dtgData.Columns.Add(column9);
            }
            LoadData();
        }

        private void LoadData(IQueryable<info_Job> data = null)
        {
            data = data ?? QL_TuyenDungEntities.info_Job
                .Include("education_level")
                .Include("priority_level")
                .Where(x => x.status_Job.Equals("Đang mở"));
            dtgData.DataSource = data.ToList();
            dtgData.Refresh();
        }

        private void Job_SizeChanged(object sender, EventArgs e)
        {
            resizeTimer.Interval = 200;
            resizeTimer.Tick += ResizeTimer_Tick;
            resizeTimer.Stop();
            resizeTimer.Start();
        }

        private void ResizeTimer_Tick(object sender, EventArgs e)
        {
            dtgData.Size = new System.Drawing.Size(this.Width - 65, this.Height - 190);
            headerPanel.Width = this.Width;
            btnAddJob.Location = new System.Drawing.Point(this.Width - 185, btnAddJob.Location.Y);
            resizeTimer.Stop();
        }

        private void ClearCurrentPanel()
        {
            if (this.Parent.Controls.Count > 1)
            {
                Control existingControl = this.Parent.Controls[0];

                if (existingControl != null)
                {
                    existingControl.Dispose();
                }
            }
        }

        private void btnAddJob_Click(object sender, EventArgs e)
        {
            if (this.Parent != null)
            {
                AddJob addJob = new AddJob(QL_TuyenDungEntities, User);

                this.Parent.Controls.Add(addJob);

                ClearCurrentPanel();
            }
        }

        private void dtgData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 8)
                {
                    if (this.Parent != null)
                    {
                        EditJob editJob = new EditJob(QL_TuyenDungEntities,
                            User,
                            dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());

                        this.Parent.Controls.Add(editJob);

                        ClearCurrentPanel();
                    }
                }
                else if (e.ColumnIndex == 9)
                {
                    ClearRow(dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());
                    LoadData();
                }
                else
                    if (this.Parent != null)
                    {
                        DetailJob detailJob = new DetailJob(QL_TuyenDungEntities,
                            User,
                            dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());

                        this.Parent.Controls.Add(detailJob);

                        ClearCurrentPanel();
                    }
            }
        }

        private void ClearRow(string jobId)
        {
            try
            {
                var confirm = MessageBox.Show("Bạn có chắc chắn muốn công việc này không?", "Xóa công việc", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    var job = QL_TuyenDungEntities.info_Job.SingleOrDefault(x => x.id.Equals(jobId));
                    QL_TuyenDungEntities.info_Job.Attach(job);
                    QL_TuyenDungEntities.info_Job.Remove(job);
                    QL_TuyenDungEntities.SaveChanges();
                    MessageBox.Show("Xóa công việc thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Xóa công việc không thành công, công việc vẫn còn đơn ứng tuyển chưa xóa", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void dtgData_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (sender is DataGridView dtgData)
            {
                if (dtgData.Columns[e.ColumnIndex].Name.Equals("educationLevel"))
                {
                    string header = QL_TuyenDungEntities.education_level
                        .Where(edu => edu.id.Equals(e.Value.ToString()))
                        .FirstOrDefault()
                        .name_level;

                    e.Value = header;
                    e.FormattingApplied = true;
                }

                if (dtgData.Columns[e.ColumnIndex].Name.Equals("priorityLevel"))
                {
                    string header = QL_TuyenDungEntities.priority_level
                        .Where(prio => prio.id.Equals(e.Value.ToString()))
                        .FirstOrDefault()
                        .name_priority;

                    e.Value = header;
                    e.FormattingApplied = true;
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var data = QL_TuyenDungEntities.info_Job
                .Include("education_level")
                .Include("priority_level")
                .Where(x => x.status_Job.Equals("Đang mở")
                && (x.title.ToLower().Contains(txtSearch.Text)));
            LoadData(data);
        }
    }
}
