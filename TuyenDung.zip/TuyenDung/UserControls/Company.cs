﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class Company : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();
        public Company()
        {
            InitializeComponent();
        }

        public Company(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void Company_Load(object sender, EventArgs e)
        {
            dtgData.AutoGenerateColumns = false;

            DataGridViewTextBoxColumn column0 = new DataGridViewTextBoxColumn();
            column0.DataPropertyName = "id";
            column0.Visible = false;

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "company_name";
            column1.HeaderText = "Tên công ty";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.DataPropertyName = "email";
            column2.HeaderText = "Email đại diện";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.DataPropertyName = "phone";
            column3.HeaderText = "Số điện thoại";

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.DataPropertyName = "address";
            column4.HeaderText = "Địa chỉ";

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.DataPropertyName = "description_company";
            column5.HeaderText = "Mô tả";

            DataGridViewButtonColumn column6 = new DataGridViewButtonColumn();
            column6.Name = "Edit";
            column6.Text = "Sửa";
            column6.UseColumnTextForButtonValue = true;

            DataGridViewButtonColumn column7 = new DataGridViewButtonColumn();
            column7.Name = "Delete";
            column7.Text = "Xóa";
            column7.UseColumnTextForButtonValue = true;

            dtgData.Columns.Add(column0);
            dtgData.Columns.Add(column1);
            dtgData.Columns.Add(column2);
            dtgData.Columns.Add(column3);
            dtgData.Columns.Add(column4);
            dtgData.Columns.Add(column5);
            if (!User.role_user.Equals("2"))
            {
                dtgData.Columns.Add(column6);
                dtgData.Columns.Add(column7);
            }
            LoadData();
        }

        private void LoadData(IQueryable<company> data = null)
        {
            data = data ?? QL_TuyenDungEntities.companies;
            dtgData.DataSource = data.ToList();
            dtgData.Refresh();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var data = QL_TuyenDungEntities.companies
                .Where(x => x.company_name.Contains(txtSearch.Text));
            LoadData(data);
        }

        private void dtgData_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

        }

        private void Company_SizeChanged(object sender, EventArgs e)
        {
            resizeTimer.Interval = 200;
            resizeTimer.Tick += ResizeTimer_Tick;
            resizeTimer.Stop();
            resizeTimer.Start();
        }

        private void ResizeTimer_Tick(object sender, EventArgs e)
        {
            dtgData.Size = new System.Drawing.Size(this.Width - 65, this.Height - 190);
            headerPanel.Width = this.Width;
            btnAddCompany.Location = new System.Drawing.Point(this.Width - 185, btnAddCompany.Location.Y);
            resizeTimer.Stop();
        }

        private void btnAddCompany_Click(object sender, EventArgs e)
        {
            if (this.Parent != null)
            {
                AddCompany addCompany = new AddCompany(QL_TuyenDungEntities, User);

                this.Parent.Controls.Add(addCompany);

                ClearCurrentPanel();
            }
        }

        private void ClearCurrentPanel()
        {
            if (this.Parent.Controls.Count > 1)
            {
                Control existingControl = this.Parent.Controls[0];

                if (existingControl != null)
                {
                    existingControl.Dispose();
                }
            }
        }

        private void dtgData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 6)
                {
                    if (this.Parent != null)
                    {
                        EditCompany editCompany = new EditCompany(QL_TuyenDungEntities,
                            User,
                            dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());

                        this.Parent.Controls.Add(editCompany);

                        ClearCurrentPanel();
                    }
                }
                else if (e.ColumnIndex == 7)
                {
                    ClearRow(dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());
                    LoadData();
                }
                else
                    if (this.Parent != null)
                    {
                        DetailCompany detailCompany = new DetailCompany(QL_TuyenDungEntities,
                            User,
                            dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());

                        this.Parent.Controls.Add(detailCompany);

                        ClearCurrentPanel();
                    }
            }
            
        }

        private void ClearRow(string companyId)
        {
            try
            {
                var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa công ty này không?", "Xóa công ty", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    var company = QL_TuyenDungEntities.companies.SingleOrDefault(x => x.id.Equals(companyId));
                    QL_TuyenDungEntities.companies.Attach(company);
                    QL_TuyenDungEntities.companies.Remove(company);
                    QL_TuyenDungEntities.SaveChanges();
                    MessageBox.Show("Xóa công ty thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Xóa công ty không thành công, công ty vẫn còn công việc chưa xóa", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            
        }
    }
}
