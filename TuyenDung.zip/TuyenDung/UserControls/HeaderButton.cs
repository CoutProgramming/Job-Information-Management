﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace TuyenDung.UserControls
{
    public partial class HeaderButton : UserControl
    {

        private bool _isCheck;
        public bool IsChecked
        {
            get => _isCheck;
            set
            {
                _isCheck = value;
                button1.Visible = _isCheck;
            }
        }

        private string _labelText;

        public string LabelText
        {
            get => _labelText;
            set
            {
                _labelText = value;
                label1.Text = _labelText;
            }
        }

        public HeaderButton()
        {
            InitializeComponent();
            IsChecked = false;
        }

        public HeaderButton(string labelText = "", bool isCheck = false)
        {
            InitializeComponent();
            LabelText = labelText;
            IsChecked = isCheck;
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            button1.Width = this.Width;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            OnClick(EventArgs.Empty);
        }
    }
}
