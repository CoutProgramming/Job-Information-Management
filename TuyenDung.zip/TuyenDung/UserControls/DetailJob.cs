﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class DetailJob : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        public string jobId { get; set; }
        private Timer resizeTimer = new Timer();
        public DetailJob()
        {
            InitializeComponent();
        }

        public DetailJob(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user, string jobId)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
            this.jobId = jobId;
        }

        private void DetailJob_Load(object sender, EventArgs e)
        {
                cboPriority.DataSource = QL_TuyenDungEntities.priority_level.ToList();
                cboPriority.ValueMember = "id";
                cboPriority.DisplayMember = "name_priority";

                cboMajor.DataSource = QL_TuyenDungEntities.majors.ToList();
                cboMajor.ValueMember = "id";
                cboMajor.DisplayMember = "name_major";

                cboCompany.DataSource = QL_TuyenDungEntities.companies.ToList();
                cboCompany.ValueMember = "id";
                cboCompany.DisplayMember = "company_name";

                cboEducation.DataSource = QL_TuyenDungEntities.education_level.ToList();
                cboEducation.ValueMember = "id";
                cboEducation.DisplayMember = "name_level";

                var job = QL_TuyenDungEntities.info_Job.SingleOrDefault(x => x.id.Equals(jobId));
                txtTitle.Text = job.title;
                txtDescription.Text = job.description_Job;
                txtSalary.Text = job.salary;
                //job.note = string.Empty;
                //job.status_Job = "Đang mở";
                txtHeadCount.Text = job.count.ToString();
                cboPriority.SelectedValue = job.priorityID;
                cboMajor.SelectedValue = job.majorID;
                cboCompany.SelectedValue = job.companyID;
                cboEducation.SelectedValue = job.educationID;

                dateTimePicker1.Value = job.time_Create ?? DateTime.Now;
        }
    }
}
