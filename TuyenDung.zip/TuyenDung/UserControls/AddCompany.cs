﻿using System;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class AddCompany : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();
        public AddCompany()
        {
            InitializeComponent();
        }

        public AddCompany(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }


        private void btnAddJob_Click(object sender, EventArgs e)
        {
            var company = new company()
            {
                id = Guid.NewGuid().ToString(),
                company_name = txtName.Text,
                address = txtAddress.Text,
                email = txtEmail.Text,
                phone = txtPhoneNumber.Text,
                description_company = txtDescription.Text,
            };
            QL_TuyenDungEntities.companies.Add(company);
            QL_TuyenDungEntities.SaveChanges();
            MessageBox.Show("Thêm công ty thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RedirectToCompanyPage();
        }

        private void RedirectToCompanyPage()
        {
            if (this.Parent.Parent is MainWindow main)
            {
                main.ChangeView(4);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RedirectToCompanyPage();
        }
    }
}
