﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class DetailCompany : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        public string companyId { get; set; }
        private Timer resizeTimer = new Timer();
        public DetailCompany()
        {
            InitializeComponent();
        }

        public DetailCompany(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user, string companyId)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
            this.companyId = companyId;
        }

        private void DetailCompany_Load(object sender, EventArgs e)
        {
            var company = QL_TuyenDungEntities.companies.SingleOrDefault(x => x.id.Equals(companyId));
            txtName.Text = company.company_name;
            txtAddress.Text = company.address;
            txtEmail.Text = company.email;
            txtPhoneNumber.Text = company.phone;
            txtDescription.Text = company.description_company;
        }
    }
}
