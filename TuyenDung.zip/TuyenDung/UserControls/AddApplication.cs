﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class AddApplication : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();

        public AddApplication()
        {
            InitializeComponent();
        }

        public AddApplication(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void btnAddApplication_Click(object sender, EventArgs e)
        {
            var apply = new apply()
            {
                id = Guid.NewGuid().ToString(),
                accountID = User.id,
                jobID = comboBox1.SelectedValue.ToString(),
                status_apply = string.Empty,
                create_Time = DateTime.Now,
            };
            QL_TuyenDungEntities.applies.Add(apply);
            QL_TuyenDungEntities.SaveChanges();
            MessageBox.Show("Thêm đơn ứng tuyển thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RedirectToHomePage();
        }

        private void RedirectToHomePage()
        {
            if (this.Parent.Parent is MainWindow main)
            {
                main.ChangeView(1);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RedirectToHomePage();
        }

        private void AddApplication_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = QL_TuyenDungEntities.info_Job
                .Where(x => x.status_Job.Equals("Đang mở")).ToList();
            comboBox1.ValueMember = "id";
            comboBox1.DisplayMember = "title";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cboPriority.DataSource = QL_TuyenDungEntities.priority_level.ToList();
                cboPriority.ValueMember = "id";
                cboPriority.DisplayMember = "name_priority";

                cboMajor.DataSource = QL_TuyenDungEntities.majors.ToList();
                cboMajor.ValueMember = "id";
                cboMajor.DisplayMember = "name_major";

                cboCompany.DataSource = QL_TuyenDungEntities.companies.ToList();
                cboCompany.ValueMember = "id";
                cboCompany.DisplayMember = "company_name";

                cboEducation.DataSource = QL_TuyenDungEntities.education_level.ToList();
                cboEducation.ValueMember = "id";
                cboEducation.DisplayMember = "name_level";

                var job = QL_TuyenDungEntities.info_Job.SingleOrDefault(x => x.id.Equals(comboBox1.SelectedValue.ToString()));
                txtTitle.Text = job.title;
                txtDescription.Text = job.description_Job;
                txtSalary.Text = job.salary;
                //job.note = string.Empty;
                //job.status_Job = "Đang mở";
                txtHeadCount.Text = job.count.ToString();
                cboPriority.SelectedValue = job.priorityID;
                cboMajor.SelectedValue = job.majorID;
                cboCompany.SelectedValue = job.companyID;
                cboEducation.SelectedValue = job.educationID;

                dateTimePicker1.Value = job.time_Create ?? DateTime.Now;
            }
            catch (Exception)
            {
            }
            
        }
    }
}
