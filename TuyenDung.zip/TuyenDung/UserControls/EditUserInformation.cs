﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class EditUserInformation : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();
        public EditUserInformation()
        {
            InitializeComponent();
        }

        public EditUserInformation(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void DoSomething()
        {
            var userInfo = QL_TuyenDungEntities.info_user.SingleOrDefault(x => x.account_user.Equals(User.id));
            userInfo.level_user = "";
            userInfo.name_user = "";
            userInfo.address = "";
            userInfo.school = "";
            userInfo.gender = true;
            userInfo.description_user = "";
            QL_TuyenDungEntities.SaveChanges();
        }
    }
}
