﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuyenDung.Models;

namespace TuyenDung.UserControls
{
    public partial class Account : UserControl
    {
        public QL_TuyenDungEntities QL_TuyenDungEntities { get; set; }
        public account_user User { get; set; }
        private Timer resizeTimer = new Timer();
        public Account()
        {
            InitializeComponent();
        }

        public Account(QL_TuyenDungEntities qL_TuyenDungEntities, account_user user)
        {
            InitializeComponent();
            QL_TuyenDungEntities = qL_TuyenDungEntities;
            User = user;
        }

        private void Account_Load(object sender, EventArgs e)
        {
            dtgData.AutoGenerateColumns = false;

            DataGridViewTextBoxColumn column0 = new DataGridViewTextBoxColumn();
            column0.DataPropertyName = "id";
            column0.Visible = false;

            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.DataPropertyName = "user_name";
            column1.HeaderText = "Username";

            DataGridViewButtonColumn column2 = new DataGridViewButtonColumn();
            column2.Name = "Reset password";
            column2.Text = "Lấy lại mật khẩu";
            column2.UseColumnTextForButtonValue = true;

            DataGridViewButtonColumn column3 = new DataGridViewButtonColumn();
            column3.Name = "Delete";
            column3.Text = "Xóa";
            column3.UseColumnTextForButtonValue = true;

            dtgData.Columns.Add(column0);
            dtgData.Columns.Add(column1);
            dtgData.Columns.Add(column2);
            dtgData.Columns.Add(column3);
            LoadData();
        }

        private void LoadData(IQueryable<account_user> data = null)
        {
            data = data ?? QL_TuyenDungEntities.account_user;
            dtgData.DataSource = data.ToList();
            dtgData.Refresh();
        }

        private void dtgData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 2)
                {
                    ResetPasswordForUser();
                }
                else if (e.ColumnIndex == 3)
                {
                    ClearRow(dtgData.Rows[e.RowIndex].Cells[0].Value.ToString());
                    LoadData();
                }
            }
        }

        private void ResetPasswordForUser()
        {

        }

        private void ClearRow(string userId)
        {
            try
            {
                var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa người dùng này không?", "Xóa người dùng", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    var user = QL_TuyenDungEntities.account_user.SingleOrDefault(x => x.id.Equals(userId));
                    QL_TuyenDungEntities.account_user.Attach(user);
                    QL_TuyenDungEntities.account_user.Remove(user);
                    QL_TuyenDungEntities.SaveChanges();
                    MessageBox.Show("Xóa người dùng thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Xóa người dùng không thành công, vẫn còn đơn ứng tuyển chưa xóa", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private string CreatePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder res = new StringBuilder();
            Random rnd = new Random();
            while (0 < length--)
            {
                res.Append(valid[rnd.Next(valid.Length)]);
            }
            return res.ToString();
        }
    }
}
